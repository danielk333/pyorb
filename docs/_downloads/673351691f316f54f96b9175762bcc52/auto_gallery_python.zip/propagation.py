'''
Distribution transformation
============================
'''

import pyorb

#We first create a standard orbit around the sun in SI units
orb = pyorb.Orbit(M0 = pyorb.M_sol)

